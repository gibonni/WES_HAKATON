#include "hcsr04.h"
#include "driver/gpio.h"
#include "esp_timer.h"
#include "esp_log.h"


#define TRIG_PIN 27U
#define ECHO_PIN 26U

static const char *TAG = "HC-SR04";

//static gpio_num_t trig_pin_global = 27U;
//static gpio_num_t echo_pin_global = 26U;

esp_err_t hcsr04_init(void) {
    gpio_num_t trig_pin_global = TRIG_PIN;
    gpio_num_t echo_pin_global = ECHO_PIN;

    gpio_config_t io_conf = {
        .intr_type = GPIO_INTR_DISABLE,
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = 1ULL << TRIG_PIN,
    };
    gpio_config(&io_conf);

    io_conf.mode = GPIO_MODE_INPUT;
    io_conf.pin_bit_mask = 1ULL << ECHO_PIN;
    gpio_config(&io_conf);

    return ESP_OK;
}

esp_err_t hcsr04_read_distance_cm(float *distance_cm) {
    uint64_t start_time = 0, end_time = 0;
    int timeout_us = 30000;  // Max 30ms

    // Send 10us pulse
    gpio_set_level(TRIG_PIN, 0);
    esp_rom_delay_us(2);
    gpio_set_level(TRIG_PIN, 1);
    esp_rom_delay_us(10);
    gpio_set_level(TRIG_PIN, 0);

    // Wait for ECHO to go HIGH
    int wait = 0;
    while (gpio_get_level(ECHO_PIN) == 0 && wait++ < timeout_us) {
        start_time = esp_timer_get_time();
    }

    if (wait >= timeout_us) return ESP_ERR_TIMEOUT;

    // Wait for ECHO to go LOW
    wait = 0;
    while (gpio_get_level(ECHO_PIN) == 1 && wait++ < timeout_us) {
        end_time = esp_timer_get_time();
    }

    if (wait >= timeout_us) return ESP_ERR_TIMEOUT;

    uint64_t pulse_duration = end_time - start_time;
    *distance_cm = (pulse_duration / 2.0f) * 0.0343f;  // Speed of sound: 343 m/s

    return ESP_OK;
}
