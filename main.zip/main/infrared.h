/*
    Header za definiciju svih potrebnih parametara za infracrveni senzor

*/

#ifndef INFRARED_H
#define INFRARED_H

#define INFRARED_D0 14U //digitalni pin za modul

// funkcija za inicijalizaciju infracr signala samo sa digitalnim izlazom
void init_Infrared_onlyD(void);

// funkcija za citanje sa digitalnog izlaza infracr senzora
int read_Infrared_digital(void);

#endif