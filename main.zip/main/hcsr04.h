#pragma once

#include "esp_err.h"
#include "driver/gpio.h"

esp_err_t hcsr04_init(void);
esp_err_t hcsr04_read_distance_cm(float *distance_cm);
